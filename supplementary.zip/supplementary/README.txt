The supplementary materials of “Embedding learning”.

- supplementary.pdf:

The supplementary materials include proofs for Lemmas 1 and 2 and Corollaries 1 and 2.

- linear_demo
- nonlinear_demo

Python code the application section for both linear and nonlinear situations.